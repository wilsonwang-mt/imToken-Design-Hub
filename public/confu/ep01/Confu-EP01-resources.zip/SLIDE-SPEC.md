# SLIDE-SPEC — Confu EP01 deck (binding contract for every builder agent)

You are writing **slide fragments only** — a sequence of `<section class="slide">…</section>`
elements. No `<html>`, `<head>`, `<style>`, `<script>`, no `<!DOCTYPE>`. All CSS and JS
already exist in the shell. **Do not invent new CSS classes and do not write `<style>` blocks.**
If you need something the class list below doesn't cover, build it with inline styles
composed from the CSS variables listed here.

Theme: **light**. Language: **Chinese body copy, English mono kickers/labels/pills.**
Occasion: a 60-minute company-wide talk, projected on a big screen. One idea per slide.

---

## 1. Slide skeleton (mandatory on every slide)

```html
<section class="slide" data-section="unique-kebab-id" data-label="侧栏悬浮标签"
         data-group="Part 1 · 方法论" data-thumb="grid3" data-thumb-color="blue"
         data-speaker-notes="讲者备注：这一页要落的那个点，节奏提示，时间。">
    <div class="stage">
        <div class="kicker">PART 1 · METHOD</div>
        <h2>标题</h2>
        <p class="subtitle" style="margin-bottom:2rem;">副标题</p>
        …内容…
    </div>
</section>
```

Rules:
- `data-section` must be **unique across the whole deck** (kebab-case).
- `data-thumb` picks the sidebar wireframe. Allowed values ONLY:
  `cover | statement | divider | grid2 | grid3 | grid4 | split | stack | table | timeline | steps | term | stat | placeholder`
  Pick the one that roughly mirrors the slide's real layout.
- `data-thumb-color`: `blue | purple | green | amber | red | gray`.
- `data-group` = the part label; it renders bottom-left. Cover/closing slides: omit it.
- `data-speaker-notes` is **required on every slide** — write real presenter cues in
  Chinese (the beat to land, timing, what to do). Escape any `"` as `&quot;`.
- **Never** add a footer, page number, or logo inside a slide — the shell renders those.
- Direct children of `.stage` are staggered in automatically (max 7 — keep it to ≤6).
- Centered slides: `<section class="slide center" …>`.
- Tinted background: add `bg-alt` to the section class.
- Wider stage: add `wide`. Top-aligned (for dense slides): add `top`.

## 2. Stepped reveal (use on diagram / flow / comparison slides)

Add `data-step="1"`, `"2"`, `"3"`… to elements. They fade+rise in sequence (420ms first
beat, 950ms gap) whenever the slide becomes active, and replay on `R`. Add a replay
affordance **inside the section, as a sibling of `.stage`**:

```html
<button class="replay">↻ replay</button>
```

Rules: 3–5 steps max per slide; group related elements under one step number; the frame
and title stay at step 0 (i.e. no `data-step` at all) so the slide never starts blank.
Add `class="scale-in"` alongside `data-step` for a hero object that should scale in.
**Do not put `data-step` on a `.stage` direct child** — it fights the entrance stagger.
Put steps on elements *inside* a wrapper div.

## 3. Design tokens (use these; never a raw hex outside this list)

```
--brand #007FFF (--brand-rgb 0,127,255) · --brand-dark #0066D6 · --brand-light #E5F2FF
--purple #7C3AED (--purple-rgb 124,58,237) · --purple-light #EDE9FE · --ai #A78BFA (AI/Agent ONLY)
--green #059669 (5,150,105) · --green-light #D1FAE5
--amber #D97706 (217,119,6) · --amber-light #FEF3C7
--red   #DC2626 (220,38,38)  · --red-light   #FEE2E2
--teal #0D9488 · --cyan #0891B2 · --cyan-light #CFFAFE
--bg #FAFCFF · --bg-alt #F0F6FF · --bg-dark #0B1120 · --surface #FFFFFF
--text #0F172A · --text-secondary #475569 · --text-muted #94A3B8
--border #E2E8F0 · --border-light #F1F5F9
--radius 16px · --radius-sm 8px · --radius-xs 4px · --radius-lg 24px
--shadow-sm/-md/-lg/-xl
--font-display / --font-body / --font-mono
```

Tints: always `rgba(var(--brand-rgb),.06)` style — never a literal indigo/emerald hex.

## 4. Class inventory (all already defined — compose these first)

**Type**: `.kicker` (+`.purple .green .amber .red`), `h1 h2 h3 h4`, `.subtitle`,
`.big-statement`, `.grad-text`, `.hairline`, `.mono`, `.muted`, `.gloss`

**Pills/labels**: `.label` + `.label-blue|purple|green|amber|red|gray`
`.spill` (dot + text status pill) + `.purple .green .amber .red .live` (pulsing dot)
`.chip` + `.purple .green .amber .red .gray .dashed`

**Cards/grid**: `.card` (+`.accent-left .purple-left .green-left .amber-left .red-left
.highlight .tight .lift`), `.card .ghost-num` (needs `position:relative` on the card),
`.grid-2 .grid-3 .grid-4 .grid-5 .grid-auto`, `.stack`, `.row` (+`.wrap`),
`.mt-1 .mt-2 .mt-3`

**Stats**: `.stat > .num + .cap`, `.stat-row`

**Tables**: `.comparison` (`.from-cell` italic-muted / `.to-cell` bold-ink),
`.schedule` + `.time-tag` (+`.purple .green .amber`)

**Flow**: `.flow-step > .flow-dot (+.purple .green .amber .red .ghost) + div`, `.flow-line`
Horizontal: `.hflow > .hstep > .fn + b + p` (auto `→` between steps, stacks on mobile)

**Blocks**: `.phase-block` + `.p1 .p2 .p3 .p4`

**Placeholder** (missing image — see §6): `.placeholder > .ph-icon .ph-title .ph-file .ph-desc`

**Terminal**: `.term > .term-bar (.dot ×3 + .ttl) + .term-body`
Inside `.term-body`: `.pr` green prompt · `.cm` gray comment · `.hl` blue · `.ok` green ·
`.wr` amber · `.em` white-bold

**Prompt block**: `.prompt > .p-head(.p-tag + .copy-btn) + .p-body`; wrap variables in
`<em>` inside `.p-body` for a highlighted token. The copy button works automatically.

**Buttons**: `.demo-btn` (+`.solid .purple .ghost`); mark unknown URLs with
`data-url-missing="1"` (renders dashed).

**Cover background**:
```html
<div class="cover-bg">
    <div class="orb" style="width:520px;height:520px;background:var(--brand);top:-12%;left:14%;"></div>
    <div class="orb" style="width:430px;height:430px;background:var(--purple);bottom:-8%;right:10%;animation-delay:-6s;"></div>
    <svg class="grid-tex" width="100%" height="100%"><defs><pattern id="gridUNIQUEID" width="60" height="60" patternUnits="userSpaceOnUse"><path d="M 60 0 L 0 0 0 60" fill="none" stroke="#0F172A" stroke-width="0.5"/></pattern></defs><rect width="100%" height="100%" fill="url(#gridUNIQUEID)"/></svg>
</div>
```
**The pattern `id` must be unique per slide** (e.g. `gridCover`, `gridClose`).

## 5. Illustration doctrine — READ THIS, it is the house style

Wilson's decks **do not use big drawn SVG illustrations**. Every "illustration" —
system maps, layer stacks, before/after, timelines, anatomies, flows — is **composed
from HTML divs**: `var(--radius)` boxes, 1–1.5px borders, 6–8% colour tints, mono
kickers, `▼`/`→`/`↑` glyph connectors, and small chips. Reproduce that.

Reference recipes (adapt, don't copy verbatim):

**Layered stack / system map** — stacked rows joined by `▼`:
```html
<div style="display:flex;flex-direction:column;gap:.7rem;">
  <div style="background:linear-gradient(135deg,var(--brand),var(--cyan));border-radius:var(--radius);padding:1.1rem 1.4rem;color:#fff;text-align:center;box-shadow:0 6px 24px rgba(var(--brand-rgb),.22);">
      <div style="font-family:var(--font-mono);font-size:.6rem;letter-spacing:.14em;opacity:.85;">LAYER LABEL</div>
      <div style="font-size:1.3rem;font-weight:700;margin-top:.25rem;">主标题</div>
  </div>
  <div style="text-align:center;font-size:1.05rem;color:var(--text-muted);line-height:1;">▼</div>
  <div style="border:1.5px solid var(--border);border-radius:var(--radius);padding:.75rem 1.1rem;background:var(--surface);">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:.4rem;">
          <div style="font-size:.72rem;font-weight:700;color:var(--green);">行标题</div>
          <span class="label label-green" style="font-size:.55rem;padding:2px 8px;">状态</span>
      </div>
      <div class="row wrap" style="gap:.4rem;"><span class="chip green">条目</span></div>
  </div>
</div>
```

**Timeline (gradient spine + cards)**:
```html
<div style="display:flex;align-items:stretch;gap:1.3rem;">
  <div style="width:6px;border-radius:3px;flex-shrink:0;background:linear-gradient(180deg,var(--brand),var(--cyan),var(--green),var(--amber),var(--purple));"></div>
  <div class="stack" style="flex:1;">
    <div class="card tight">
      <div class="row" style="margin-bottom:.3rem;">
        <span class="mono" style="font-size:.7rem;font-weight:700;color:var(--brand);letter-spacing:.1em;">03 · MAR</span>
        <span class="muted" style="font-size:.72rem;margin-left:auto;">右侧元信息</span>
      </div>
      <h4>事件</h4><p style="margin:0;font-size:.84rem;">一句话</p>
    </div>
  </div>
</div>
```

**Horizontal timeline (compact, for dense date rows)** — a 2px rail with dots:
```html
<div style="position:relative;padding:2.2rem 0 .5rem;">
  <div style="position:absolute;left:0;right:0;top:2.9rem;height:2px;background:linear-gradient(90deg,var(--brand),var(--purple));opacity:.35;"></div>
  <div style="display:grid;grid-template-columns:repeat(6,1fr);gap:.5rem;position:relative;">
    <div style="text-align:center;">
      <div class="mono" style="font-size:.62rem;color:var(--brand);font-weight:700;letter-spacing:.08em;margin-bottom:.5rem;">MAR 04</div>
      <div style="width:11px;height:11px;border-radius:50%;background:var(--brand);margin:0 auto .6rem;border:2.5px solid var(--bg);box-shadow:0 0 0 2px rgba(var(--brand-rgb),.3);"></div>
      <div style="font-size:.78rem;font-weight:650;color:var(--text);">节点名</div>
      <div class="gloss" style="margin-top:.2rem;">产出</div>
    </div>
  </div>
</div>
```

**Before / after**: use `.comparison` with `.from-cell` / `.to-cell`, or two side-by-side
cards where the "before" card is `border-color:var(--border);opacity:.72` with muted
italic body and the "after" card is `.accent-left` with full-ink bold body.

**Annotated file/document anatomy** (e.g. dissecting CLAUDE.md): a bordered "document"
box on the left made of `.chip`-like rows, numbered `.flow-dot`-sized circles hanging on
its edge, and a numbered legend column on the right in a `grid-template-columns:26px 1fr`.

**Icons**: Lucide/Feather-style inline SVG only — `viewBox="0 0 24 24" fill="none"
stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"`,
sized 15–24px. **NO EMOJI as iconography anywhere on a content slide.** (Emoji is
tolerated only inside prose where it is literally the subject, and inside `.placeholder`
is not needed — that has `.ph-icon`.)

## 6. Images — placeholders only (Wilson fills them tomorrow)

Every image slot must be a labelled placeholder that auto-upgrades when the file appears:

```html
<div class="placeholder" style="min-height:260px;">
    <svg class="ph-icon" width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
    <div class="ph-title">Cowork 生成任务列表截图</div>
    <div class="ph-file">assets/demo-cowork-tasklist.png</div>
    <div class="ph-desc">建议 ~1600px 宽；把任务勾选状态拍全。</div>
    <img src="assets/demo-cowork-tasklist.png" alt="" onerror="this.remove()">
</div>
```
The `<img>` must come **last** and carry `onerror="this.remove()"`. Filenames: kebab-case,
prefixed by the part (`opening-`, `m1-`, `demo-`, `ws-`, `jobs-`, `close-`).
**Never fabricate a screenshot and never leave an empty gap.**

## 7. URLs — dual safety

Wilson does not know the final URLs yet. Every link that should open in an overlay:

```html
<button class="demo-btn" data-url-missing="1"
        onclick="toggleDesktopModal('REPLACE_ME_URL','Sigil on OpenClaw Demo · Cowork 生成结果')">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="14" rx="2"/><path d="M8 21h8M12 18v3"/></svg>
    打开生成结果
</button>
```
Use the literal token `REPLACE_ME_URL` (Wilson search-replaces it). The modal already
falls back to a "新标签打开" card when a site refuses framing — you don't handle that.
For a phone-sized prototype use `toggleDemoPanel('REPLACE_ME_URL')` instead.

## 8. Density & rhythm (the numbers that make it look composed)

- kicker → h2: built in (1rem). h2 → subtitle: built in (1rem).
- subtitle → body: set inline `margin-bottom:2rem` (dense) or `2.5rem` (airy).
- grid gaps 1.1rem default; card padding 1.6rem, `.tight` 1.15rem for 3-up/4-up.
- Body copy on content slides: `0.84–0.95rem` inside cards, never below `0.7rem`.
- Max ~6 cards on a slide. Max 6 rows in a table. If it doesn't fit, split the slide —
  **never shrink the font to fit**.
- Content max-width is handled by `.stage` (1280px / 1440px with `wide`).
- Every slide must survive being read from the back of a room: the single most important
  line on the slide should be ≥1.6rem.

## 9. Hard rules

1. No `<style>`, no `<script>`, no new classes.
2. No emoji as icons. No `①②③` glyphs — use `.flow-dot`.
3. Unique `data-section` and unique SVG `id`s.
4. `data-speaker-notes` on every slide.
5. Never invent facts. Only use content given to you in the brief. If a number or claim
   isn't in your brief, don't write it.
6. Chinese body copy; technical terms stay English (Skill, Prompt, Cowork, Claude Code,
   Agent, Slide, Context, Workshop, Custom GPT, AGENTS.md…).
7. Output raw HTML fragments as your final message. No markdown fences around the whole
   thing, no commentary before or after.
