# Dark theme — the house dark style (from the Sigil all-hands deck)

Source of truth: `about-sigil/deck-allhands.html` + its three animated
sub-diagrams. This file distills that deck into reusable tokens and recipes.
A dark deck built with this skill should be indistinguishable in quality from
the Sigil deck.

## Palette

```css
--bg: #0a0e1a;               /* page base — near-black navy, never pure #000 */
--bg-deep: #0a1024;          /* hero/cold-open panels */
--panel: #14203f;            /* gradient inner stop */
--panel-2: #0d1838;          /* card gradient stop / badge fill */
--brand: #5aa6ff;            /* azure remapped for dark bg (NOT #007FFF) */
--brand-soft: #7fb6ff;       /* hover / shimmer highlight */
--brand-alt: #6fb0ff;
--green: #7ff0c4;   --green-deep: #10b981;
--amber: #ffd27d;   --amber-deep: #e8a317;
--orange: #ff8f6b;           /* danger/warning accents in dark decks */
--pink: #ff9aa9;    --red-deep: #d4183d;
--ai: #c9a6ff;               /* AI/Agent content only (dark remap of #A78BFA) */
--text: #ffffff;
--text-secondary: rgba(255,255,255,.62);   /* body copy */
--text-muted: rgba(255,255,255,.4);        /* captions, placeholder labels */
--mono-gray: #cdd6e4;        /* mono pills, secondary mono text */
--dot: #3a4a66;              /* separator dots, inactive arrows */
```

## Background recipes

- **Standard slide**: `radial-gradient(120% 90% at 20% 12%, #14203f 0%, #0a0e1a 72%)`
  — vary the `at X% Y%` origin per slide (top-left for content, center-left
  24% 50% for part dividers, top-center 50% 4% for diagrams) so consecutive
  slides don't feel copy-pasted.
- **Danger/incident slide**: `radial-gradient(120% 100% at 50% 0%, #2a160f 0%, #0a0e1a 66%)`
  — warm dark top glow signals "this is the scary part".
- **Photo-hero slide**: layer a directional fade over the image so text stays
  readable: `linear-gradient(90deg, #0a1024 0%, rgba(10,16,36,.84) 36%,
  rgba(10,16,36,0) 66%), url('…') right center / contain no-repeat, #0a1024`.
- **Glow orb** (behind logos/hero objects): absolutely-positioned circle with
  `background: radial-gradient(circle, rgba(0,127,255,.22), transparent 66%)`.

## Typography scale (1920×1080 design canvas)

| Role | Spec |
|---|---|
| Eyebrow / kicker | JetBrains Mono, 22–26px, `letter-spacing:.3em`, uppercase, `--brand` |
| Hero headline | Inter 800–900, 86–104px, `letter-spacing:-.02em ~ -.03em`, `line-height:1.0–1.05`, one key word tinted `--brand` (or `--orange` for danger) |
| Section headline | Inter 800, 58–66px |
| Card title | Inter 700, 27–40px |
| Body / card copy | Inter 400, 20–34px, `--text-secondary`, `line-height:1.45–1.5` |
| Mono pill / tag | JetBrains Mono 18–28px in a `border-radius:999px` outline pill |
| Giant part number | JetBrains Mono 800, 224px, `line-height:.86`, with shimmer |

Brand-name wordmarks (product names like *Sigil*) may use
`Georgia, serif; font-style:italic; font-weight:700` + shimmer for contrast
against the geometric Inter — use sparingly, cover + closing only.

## Components

**Card**: `background:rgba(255,255,255,.04); border:1px solid
rgba(255,255,255,.1); border-radius:24–28px; padding:~42px`.
Accent-tinted variant: swap both to the accent, e.g.
`background:rgba(90,166,255,.06); border-color:rgba(90,166,255,.32)`.
Use tinted borders to color-code columns of a comparison (blue = us,
amber = untrusted, green = owner/safe — the Sigil three-zone pattern).

**Icon tile**: 78–104px square, `border-radius:20–24px`, accent at 8–14%
alpha as fill (`rgba(90,166,255,.14)`), containing a stroked SVG icon in the
matching accent.

**Mono pill**: `font-family:mono; border:1px solid rgba(255,255,255,.16);
border-radius:999px; padding:12px 24px; color:#cdd6e4`. Used for presenter
names, version tags, verb chips. Warning variant tints border+text amber.

**Glass chip** (floating UI like a Back button):
`background:rgba(255,255,255,.08); backdrop-filter:blur(14px) saturate(160%);
border:1px solid rgba(255,255,255,.16); border-radius:999px`.

**Numbered agenda row**: mono number 44px in `--brand` + title 40px/700 +
subtitle 24px muted + right-aligned mono pill (owner), rows separated by
`border-top:1px solid rgba(255,255,255,.1)`.

**Placeholder box** (see SKILL.md Step 5): dashed
`border:1px dashed rgba(90,166,255,.42)` on `rgba(255,255,255,.03)`, mono
label + expected filename, `<img … onerror="this.remove()">` overlay.

## Shimmer headline

```css
.shimmer {
  background: linear-gradient(100deg, #fff 35%, #7fb6ff 50%, #fff 65%);
  background-size: 220% auto;
  -webkit-background-clip: text; background-clip: text;
  -webkit-text-fill-color: transparent; color: transparent;
  animation: sheen 7s linear infinite; will-change: background-position;
}
@keyframes sheen { 0% {background-position:200% 0;} 100% {background-position:-200% 0;} }
```

Reserve for: cover title, giant part numbers, closing line. Never body text.

## Inline-SVG illustration standard

Concept slides use hand-authored inline SVG mini-scenes instead of stock
icons — e.g. a terminal window with traffic-light dots + prompt lines + a
gear, a globe with orbiting message/API nodes, a wallet with an outbound
arrow to a coin. Rules:

- ~88–120px viewBox scenes inside icon tiles; stroke-based, 1.4–2.4px
  strokes in the accent palette; `<defs>` gradients for depth
  (`#1a2b52 → #0d1838`); dashed strokes (`stroke-dasharray:1 4`) for
  connections/associations; mono `<text>` labels where meaningful (`{ }`).
- Big diagram slides: one full-bleed `<svg viewBox="0 0 1900 900">` with
  zone panels (tinted rounded rects + mono zone labels), numbered badge
  circles on connectors, solid vs dashed line vocabulary (solid = active/
  trusted path, dashed = passive/notification), and a bottom legend row
  explaining every line style. Color-code zones semantically.
- Every diagram gets stepped reveal (`references/motion-interactions.md`).

## Dark-mode logo

Footer center, every slide: white wordmark PNG (`assets/imtoken-logo-dark.png`
in this skill) base64-inlined, `height:26px; opacity:.82;
filter:drop-shadow(0 2px 6px rgba(0,0,0,.4))`, positioned
`absolute; left:50%; bottom:48px; transform:translateX(-50%)`.

## Don'ts

- No pure-black background, no pure-gray cards (always navy-tinted).
- No #007FFF text/strokes on the dark bg (fails contrast) — use #5aa6ff.
- No more than one shimmer element visible per slide.
- Don't mix warm-glow (danger) and cool-glow backgrounds on one slide.
- Photos never sit borderless on the bg: round corners (22px) and either a
  dashed placeholder frame or a gradient fade into the slide.
