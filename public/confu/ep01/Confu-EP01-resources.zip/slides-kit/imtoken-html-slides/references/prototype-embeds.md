# Prototype overlays — mobile panel & desktop modal

Rule: a deck never navigates away to open a prototype. Prototypes open **inside
the deck** so the presenter's place and context are preserved. Both mechanisms
are already wired in the templates (`toggleDemoPanel`, `toggleDesktopModal`,
`Esc` closes either).

## Which overlay for which prototype

| Prototype viewport | Overlay | Motion |
|---|---|---|
| Mobile (390–430 px wide) | Right **slide-in panel**, 440px wide, phone frame 393×852 | translateX(100%) → 0, 0.4s; deck content pads left to stay visible |
| Desktop / tablet (responsive web) | **Center modal**, min(1280px, 90vw) × min(800px, 88vh), macOS-style browser bar | backdrop fade + scale 0.96 → 1 fade-in, 0.35s |

Deciding factor is the prototype's own layout, not where the deck is shown.
If one feature has both, put two `.demo-btn` buttons on the slide.

## Trigger markup

```html
<button class="demo-btn" onclick="toggleDemoPanel('prototypes/send-flow.html')">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/></svg>
    手机原型 · Send Flow
</button>

<button class="demo-btn" onclick="toggleDesktopModal('prototypes/dashboard-desktop.html')">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="14" rx="2"/><path d="M8 21h8M12 18v3"/></svg>
    桌面原型 · Dashboard
</button>
```

Button label pattern: `手机原型 · [Feature]` / `桌面原型 · [Feature]` (or English
equivalents in an English deck). Place buttons under the slide's subtitle.

## Behavior details (already implemented — don't break these)

- Clicking a second mobile trigger while the panel is open **swaps the iframe
  URL** without closing the panel (smooth screen-to-screen comparison).
- Closing resets `iframe.src` to `about:blank` after the exit transition, so
  prototype audio/timers stop and reopening starts fresh.
- Mobile panel pushes deck content (`body.demo-open` padding) — the presenter
  can keep talking over the visible slide while the prototype runs.
- Desktop modal backdrop click (outside the frame) closes; clicks inside the
  iframe never close it.
- `Esc` closes whichever overlay is open (`closeAllOverlays()`).

## File layout & the one allowed relative path

Decks are self-contained EXCEPT prototype iframes and screenshot `<img>`s,
which reference sibling files by relative path:

```
Phase X/
├── my-deck-slides.html
└── prototypes/
    ├── send-flow.html          ← mobile prototype (390×844 design, self-contained)
    └── dashboard-desktop.html  ← desktop prototype (self-contained)
```

When delivering a deck with embedded prototypes, always tell Wilson which
sibling files must travel with it (GitHub Pages upload, sharing, etc.).

## Embedding a live URL — most sites refuse

**Do not put a Feishu doc, Confluence page, Figma file, ChatGPT share link, or
any similar SaaS URL in a prototype iframe and assume it will render.** They all
send `X-Frame-Options: DENY` / a restrictive `frame-ancestors` CSP. What the
room sees is a full-size white rectangle behind a browser chrome mock. The old
"absolute `http(s)://` URLs also work" line in this file was wrong.

Two facts that make this hard to detect, both verified:

- **Chrome fires `load` on a refused frame.** Serving a page with
  `X-Frame-Options: DENY` still triggers `iframe.onload` exactly once, on time.
  `onload` is therefore useless as a success signal — it tells you the
  navigation finished, not that anything painted.
- **Cross-origin gives identical readings either way.** For both a refused
  frame and a perfectly embedded one, `iframe.contentDocument` is `null` and
  `contentWindow.origin` throws `SecurityError`. There is no property that
  distinguishes them. Refusal is genuinely unknowable from the parent frame.

So the only correct handling is **three states, not two**:

| Verdict | How you get it | What to show |
|---|---|---|
| `ok` | same-origin, `body.childElementCount > 0` | nothing |
| `empty` | same-origin, `body.childElementCount === 0` | **full-cover card** — wrong path or missing file, the deck's own bug |
| `unknown` | cross-origin, cannot inspect | **non-blocking bottom strip** with an "open in new tab" button |

Never full-cover on `unknown`. A cross-origin site that *did* embed correctly
would get hidden behind a false alarm mid-presentation.

```js
frameProbe = setTimeout(() => {
    let verdict = 'unknown';
    try {
        const d = iframe.contentDocument;
        if (d && d.body) verdict = d.body.childElementCount > 0 ? 'ok' : 'empty';
    } catch (_) { verdict = 'unknown'; }
    if (verdict === 'empty') fallback.classList.add('show');
    else if (verdict === 'unknown') fallback.classList.add('hint');
}, 2200);
```

2.2s is the tuned delay: long enough that a slow same-origin page has painted,
short enough that the presenter isn't left staring. `clearTimeout(frameProbe)`
on every open/close/swap, and clear both `.show` and `.hint` when resetting.

The escape-hatch copy should tell the presenter their place is kept:

> 看不到内容？Confluence、Figma、ChatGPT 这类站点会拒绝被嵌入。点右边在新标签打开
> —— 讲完切回来，这一页还在。

**Recommended: don't embed a live URL at all.** Save the page you want to demo
as a local HTML file into `assets/` and reference it by relative path. Same
origin, guaranteed embeddable, probes as `ok`, and it works with the venue Wi-Fi
down. Reserve live URLs for things that must be live (a running prototype
server), and always pair them with the fallback card above.

## Sandbox warning — wrap every history API call

When the deck itself is loaded inside a sandboxed iframe — a preview panel, an
`about:srcdoc` document, a cross-origin embed — `history.replaceState` throws
`SecurityError`, **and it throws once per page turn**, filling the console and
aborting whatever ran after it in `go()`.

Every `history.replaceState` / `history.pushState` / `location.hash` read or
write must be wrapped:

```js
try { if (history.replaceState) history.replaceState(null, '', '#/' + (cur + 1)); } catch (_) {}
```

Same for the deep-link restore on load. Failing silently is correct here — the
deck works fine without URL sync.

## Image lightbox (click to enlarge)

The paged templates ship a lightbox so a screenshot on a slide can be blown up
without leaving the deck. Markup:

```html
<div class="placeholder has-zoom" style="height:min(41rem, 64vh);padding:0;">
    <!-- placeholder icon/title/desc stay underneath; the img covers them once it loads -->
    <img class="zoomable" src="assets/demo-cowork-tasklist.png" alt="Cowork 任务列表" title="点击放大"
         style="object-fit:contain;background:var(--surface);border-radius:var(--radius);"
         onclick="openLightbox(this.src, this.alt)" onerror="this.remove()">
    <span class="zoom-hint">
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3M11 8v6M8 11h6"/></svg>
        点击放大
    </span>
</div>
```

- `class="zoomable"` + `onclick="openLightbox(this.src, this.alt)"` on the
  `<img>`; `.has-zoom` on the wrapper reveals the `.zoom-hint` capsule on hover.
- `onerror="this.remove()"` makes the placeholder underneath reappear if the
  asset is missing — never a broken-image icon on a projector.
- Closes on click anywhere or `Esc`, via `closeAllOverlays()`. **Closing keeps
  the current slide** — no page change, no stepped-reveal replay, no lost state.
  Add `.lightbox` to `INTERACTIVE_SEL` and to `overlayOpen()` so the click-to-page
  handler and `Esc` behave.

Two sizing rules, both learned the hard way:

- The lightbox `img` uses `width:100%; height:100%; object-fit:contain`.
  **Do not use `max-width` / `max-height`** — those only cap, never upscale, so
  on a 4K display a small screenshot opens *smaller than it looked on the slide*.
- A portrait screenshot dropped into a landscape placeholder must override
  `object-fit` to `contain`. The default `cover` crops top and bottom: a
  measured 846×1026 portrait capture in a 300px-tall box showed only 31% of the
  image, and the cropped-away part was the content being discussed.

## Caveats

- `file://` + iframe works in Chrome/Safari for sibling paths. Absolute
  `http(s)://` URLs are a last resort — see the section above; they need venue
  Wi-Fi *and* a site that permits framing.
- The phone frame is fixed 393×852 (iPhone-class). Prototypes designed at
  390×844 render fine. Don't resize the frame per prototype — consistency
  beats pixel-perfection here.
- If a prototype needs the deck's password gate (pw-gate.js), the gate runs
  inside the iframe too; test that the gate UI fits the phone frame.
