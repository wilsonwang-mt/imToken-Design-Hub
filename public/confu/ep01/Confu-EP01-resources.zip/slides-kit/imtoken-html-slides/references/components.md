# Component catalog — imToken slides

Reusable slide components proven across UI 3.0 and Confu decks. **Coverage
differs per template — do not assume a class exists.** Compose these before
inventing new patterns; when you do invent one, keep it on the same tokens (no
new hex colors) and add it here if it's likely to recur.

## Coverage — check before you use

| Group | `template-paged.html` / `template-paged-dark.html` (v2.2) | `template-scroll.html` |
|---|---|---|
| Core: `.card` + `accent-left/purple-left/green-left/amber-left/red-left`, `.grid-2/3/4`, `.label` + colors, `.kicker` / `.slide-label`, `.cover-bg`/`.orb`, `.demo-btn` | yes | yes |
| `.comparison`, `.flow-step`/`.flow-dot`/`.flow-line`, `.placeholder`, `.card.highlight`, `.glass-overlay` | yes | yes |
| v2.2 additions: `.chip`, `.spill`, `.stat`/`.stat-row`, `.hflow`/`.hstep`, `.schedule`/`.time-tag`, `.phase-block`, `.prompt`/`.copy-btn`, `.term`, `.big-statement`, `.grad-text`, `.hairline`, `.gloss`, `.mono`, `.muted`, `.label.cn`, `.grid-5`, `.grid-auto`, `.card.tight/.lift`, `.card .ghost-num` | yes | **no — paste the CSS in** |
| Image lightbox: `.zoomable`, `.has-zoom`, `.zoom-hint`, `.lightbox` + `openLightbox()` | yes (paged only) | no |
| Stepped reveal: `[data-step]`, `.replay`, `playSteps()` | yes | no |

**Hard rule:** before writing a class name into a slide, grep the template you
actually started from for that selector. If it isn't there, copy the rule into
the deck's own `<style>` (the v2.2 CSS block at the bottom of this file is
paste-ready). Never assume it exists — an unstyled class renders as plain text
and the model that wrote it cannot see the failure.

## Labels & kickers

```html
<div class="slide-label">Part 1 · Vision</div>          <!-- scroll template -->
<div class="kicker">Part 1 · Vision</div>               <!-- paged template -->
<span class="label label-blue">Foundation</span>         <!-- pill: blue/purple/green/amber/red/gray -->
<span class="label label-purple cn">上下文管理</span>     <!-- Chinese pill: .cn is MANDATORY -->
```

English kickers/labels are mono, uppercase. **Any `.label` containing Chinese
must also carry `.cn`** — see "Chinese typography red lines" below.

## Cards

```html
<div class="card accent-left">          <!-- left border: accent-left(blue) purple-left green-left amber-left red-left -->
    <h3>Title</h3>
    <p>Body copy…</p>
</div>
<div class="card highlight">…</div>     <!-- tinted bg, no border -->
<div class="card tight">…</div>         <!-- 1.15rem/1.3rem padding, for dense grids -->
<div class="card lift">…</div>          <!-- hover raise 3px + shadow-md -->
<div class="card tight" style="position:relative;">
    <span class="ghost-num">01</span>   <!-- needs position:relative on the card -->
    …
</div>
```

Use `grid-2` / `grid-3` / `grid-4`, or `grid-5` (auto-fit, min 190px) and
`grid-auto` (auto-fit, min 300px) when the item count varies. One card = one
idea; 3–6 lines max inside a card.

## Chips (small inline tags)

```html
<span class="chip">Claude Code</span>
<span class="chip purple">Cowork</span>          <!-- purple / green / amber / red / gray -->
<span class="chip dashed gray">未验证</span>      <!-- .dashed = tentative / planned -->
<span class="chip green"><svg …></svg> 已上线</span>   <!-- svg auto-sized to 13px -->
```

`display:inline-flex`, radius 8px, 6% tinted bg + 16% border of the accent.
Use for tool names, tags, inline enumerations. Not a button — never clickable.

## Status spills (pill with leading dot)

```html
<span class="spill"><span class="dot"></span>Baseline</span>
<span class="spill green live"><span class="dot"></span>正在运行</span>   <!-- .live pulses the dot -->
<span class="spill red"><span class="dot"></span>这不是时间管理问题</span>
```

Bigger and rounder than `.chip` (radius 100px, 0.82rem) — one per slide, as a
verdict or state line. Colors: default blue, `.purple .green .amber .red`.
`.live` animates the dot (`pulseDot`, 1.6s) — decoration only, never on
informational text.

## Stats / big numbers

```html
<div class="stat-row">
    <div class="stat"><div class="num">4/27</div><div class="cap">启动日</div></div>
    <div class="stat"><div class="num">3×</div><div class="cap">吞吐提升</div></div>
</div>
```

`.num` is mono, `clamp(2rem, 3.6vw, 3rem)`, brand→purple gradient clipped to
text. `.cap` is the caption underneath. `.stat-row` is a wrapping flex with
2.5rem gaps. Don't hand-roll the gradient inline any more — use `.stat .num`.

## Horizontal flow (`.hflow`)

```html
<div class="hflow">
    <div class="hstep"><div class="fn">Input</div><b>收集上下文</b><p>把散落的材料喂进去</p></div>
    <div class="hstep"><div class="fn">Process</div><b>结构化</b><p>提炼成 spec</p></div>
    <div class="hstep"><div class="fn">Output</div><b>产出</b><p>可执行的产物</p></div>
</div>
```

Arrows between steps are automatic (`.hstep + .hstep::before` renders `→`);
do not type them. Below the narrow breakpoint the row stacks vertically and the
arrow flips to `↓` on its own. `.fn` is a mono uppercase micro-label (English
only — it carries `text-transform:uppercase`), `b` is the step title, `p` the
description. 3–5 steps; more than that, split the slide.

For vertical processes keep using `.flow-step` / `.flow-dot` / `.flow-line`.

## Schedule table

```html
<table class="schedule">
    <thead><tr><th>时间</th><th>环节</th><th>产出</th></tr></thead>
    <tbody>
        <tr><td><span class="time-tag">09:30</span></td><td>开场</td><td>—</td></tr>
        <tr><td><span class="time-tag purple">10:15</span></td><td>动手</td><td>一份 spec</td></tr>
    </tbody>
</table>
```

`.time-tag` is a mono pill; `.purple .green .amber` re-tint it to segment the
agenda by track. Headers are body-font 0.8rem (not uppercase) so Chinese
headers set correctly.

## Comparison table (paradigm shift, before/after)

```html
<table class="comparison">
    <thead><tr><th>Dimension</th><th>UI 2.x</th><th>UI 3.0</th></tr></thead>
    <tbody>
        <tr><td>入口</td><td class="from-cell">链/账户优先</td><td class="to-cell">Token 优先</td></tr>
    </tbody>
</table>
```

Use `.from-cell` (muted italic) / `.to-cell` (full-contrast semibold) instead
of inline styles. Keep ≤ 6 rows per slide; split across slides rather than
shrinking the font.

## Phase blocks (roadmap stages)

```html
<div class="phase-block p1"><h3>Phase 1 · 打地基</h3><p>…</p></div>
<div class="phase-block p2">…</div>   <!-- p1 blue · p2 purple · p3 amber · p4 green -->
```

Tinted gradient + 4px left border, one per phase. Stack in a `.stack` or
`grid-2`. Four phases max — that's all the variants there are.

## Prompt block (copy-to-clipboard)

```html
<div class="prompt">
    <div class="p-head">
        <span class="p-tag">Prompt</span>
        <button class="copy-btn">复制</button>
    </div>
    <div class="p-body">
        帮我把 <em>这份会议纪要</em> 整理成 <em>一页 spec</em>，输出 Markdown。
    </div>
</div>
```

The copy handler is delegated (it reads `.p-body` innerText) — the button needs
no `onclick`. `<em>` inside `.p-body` renders as a brand-tinted variable slot,
not italics; use it for every value the audience is meant to swap.

## Terminal block

```html
<div class="term">
    <div class="term-bar">
        <span class="dot" style="background:#FF5F57;"></span>
        <span class="dot" style="background:#FEBC2E;"></span>
        <span class="dot" style="background:#28C840;"></span>
        <span class="ttl">claude — zsh</span>
    </div>
    <div class="term-body">
<span class="pr">$</span> claude "把这份 PRD 拆成 sprint"
<span class="cm"># 读取 3 个文件…</span>
<span class="hl">plan.md</span> 已生成 <span class="ok">✓</span>
<span class="wr">! 2 个待确认项</span>
<span class="em">Done in 41s</span>
    </div>
</div>
```

Always dark, in both light and dark decks. Span roles: `.pr` green prompt ·
`.cm` gray comment · `.hl` blue highlight · `.ok` green · `.wr` amber ·
`.em` white bold. Keep to ~8 lines; it is a prop, not a log dump.

## Typography atoms

```html
<h1 class="big-statement">上下文，才是<span class="grad-text">瓶颈</span></h1>
<div class="hairline"></div>                      <!-- 64×2 gradient rule under a heading -->
<p class="gloss">2026-08 · Confu EP01</p>         <!-- .78rem secondary-color meta line -->
<span class="mono">v2.2</span>                    <!-- English/numerals ONLY -->
<span class="muted">decorative</span>             <!-- decoration ONLY — see red line #4 -->
```

`.big-statement` is `clamp(2.4rem, 5.4vw, 4.4rem)` display weight 800 — one per
slide, on statement slides only. `.grad-text` clips the brand→purple gradient
to any inline span.

## Placeholder (missing screenshot / WIP asset)

Never leave an empty gap and never fake a screenshot. Use:

```html
<div class="placeholder">
    <div class="icon">🖼</div>
    <div class="title">Prototype screenshot — [screen name]</div>
    <div class="desc">Will be replaced with the Figma export / live capture</div>
</div>
```

When the real image lands, drop it inside the same `.placeholder` box and add
`.has-zoom` + `class="zoomable"` — see `prototype-embeds.md` § lightbox.

## Glass overlay (content exists but will be presented live)

Absolutely-positioned frost layer over a slide whose detail will be shown live
(used on walkthrough slides 18–24 of the design proposal):

```html
<section class="slide" data-section="home" …>
    <!-- real content underneath -->
    <div class="glass-overlay">
        <div class="glass-text-en">Live Prototype Walkthrough</div>
        <div class="glass-text-cn">原型将在工作坊现场演示</div>
    </div>
    <div class="slide-footer">…</div>
</section>
```

Footer must sit OUTSIDE/above the overlay (z-index 2 vs overlay 10 — put the
footer after the overlay in DOM or raise its z-index) so page numbers stay visible.
Check visually.

## Cover orbs (cover / part-divider / closing slides)

```html
<div class="cover-bg">
    <div class="orb" style="width:480px;height:480px;background:var(--brand);top:-10%;left:15%;"></div>
    <div class="orb" style="width:400px;height:400px;background:var(--purple);bottom:-5%;right:10%;animation-delay:-6s;"></div>
</div>
```

Two orbs max, brand + purple, opacity handled by the class. Optionally add the
faint grid pattern SVG from past decks for texture.

## Principle / split hero (text left, visual right)

```html
<div style="display:grid;grid-template-columns:1fr 1fr;gap:4rem;align-items:center;">
    <div>
        <div class="slide-label">Principle 01</div>
        <h2>Token-Centric</h2>
        <p class="subtitle">…</p>
    </div>
    <div style="display:flex;justify-content:center;">
        <div style="width:260px;">
            <img src="Assets/[file].png" alt="…" style="width:100%;display:block;border-radius:24px;box-shadow:0 8px 40px rgba(0,0,0,0.15);">
        </div>
    </div>
</div>
```

Screen PNGs that already contain a device frame get NO extra frame — just
radius + shadow (matches the design-proposal rule). Collapse to single column
below 1100px (the scroll template's `.principle-hero` media query shows how).

## Team avatars

```html
<div style="display:flex;gap:12px;justify-content:center;">
    <div style="text-align:center;">
        <div style="width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,var(--brand-light),var(--purple-light));display:flex;align-items:center;justify-content:center;font-weight:700;font-size:0.8rem;color:var(--brand);border:2px solid #fff;box-shadow:var(--shadow-sm);">WW</div>
        <div style="font-size:0.7rem;color:var(--text-secondary);margin-top:4px;">Wilson</div>
    </div>
</div>
```

## Timeline / sprint bars (roadmap slides)

Grid-based horizontal bars, one row per workstream. Solid gradient bar =
committed sprint; dashed lighter bar = later sprint (opacity 0.7 → 0.5):

```html
<div style="display:grid;grid-template-columns:repeat(8,1fr);gap:4px;">
    <div style="grid-column:1/4;background:linear-gradient(90deg,var(--green),var(--green-light));border-radius:4px;padding:4px 8px;font-size:0.65rem;font-weight:600;color:#fff;">Sprint 1 · 创建+备份</div>
    <div style="grid-column:4/6;background:var(--green-light);border:1px dashed var(--green);border-radius:4px;padding:4px 8px;font-size:0.65rem;font-weight:600;color:var(--green);">Sprint 2 · 恢复</div>
</div>
```

Don't dim the later bar with `opacity` — see red line #6. Distinguish by fill
(solid vs tinted) and border style (solid vs dashed) instead.

## Icons

Lucide-style inline SVG, 1.5px stroke, `currentColor`, 20–24px. No emoji as
icons on content slides (emoji acceptable inside `.placeholder` only). No icon
font libraries.

---

# Chinese typography red lines

Every rule below cost a real deck a real defect. They are not preferences.

**1. `.label` with Chinese needs `.cn`.**
`.label` carries `text-transform:uppercase` + `letter-spacing:.1em`. Letter
spacing applies *between Chinese glyphs*, so 「设计师」 renders as 「设 计 师」 —
looks like a typo from the back of the room. `.cn` turns uppercase off, drops
tracking to `.02em`, and lifts the size to `.76rem` (Chinese needs more optical
size than Latin at the same nominal px). Mandatory on any `.label` containing
even one Chinese character.

**2. Table headers were the same bug.** `.comparison th` and `.schedule th`
originally shipped uppercase + `.1em` tracking. As of v2.2 both are `.8rem` /
`.02em` / `--text-secondary` / `var(--font-body)`. If you paste an older
version of these rules into a deck, fix the headers too.

**3. `.mono` has no Chinese glyphs.** JetBrains Mono is Latin-only; Chinese
falls through to the generic `monospace` family, which renders wide, loose and
visually ragged next to the Latin run. Mixed-language meta lines (dates +
Chinese labels, `01 / 24 · 上下文管理`) must use the body font. Keep `.mono`
for the pure-Latin fragments only — `.time-tag`, `.fn`, `.p-tag`, version
strings, page numbers.

**4. `--text-muted` is decoration, never information.**
`--text-muted` (`#94A3B8`) on `--bg` (`#FAFCFF`) measures **2.49:1** — WCAG AA
body text needs 4.5:1. It is legal on `.ghost-num`, hairlines, disabled
affordances, and other pixels nobody has to read. Any sentence that carries
meaning uses `--text-secondary` (`#475569`, **7.4:1**). v2.2 already moved
`.gloss` from muted to secondary and raised it `.7rem → .78rem` for this reason.

**5. Projection floor is 0.62rem.** Anything smaller is unreadable past the
third row of a meeting room. Mono micro-labels (`.fn`, `.p-tag`, `.zoom-hint`)
may sit at `.63–.66rem` because they are short and all-caps; body copy,
captions and table cells may not. Below-floor text is not a "dense slide", it's
a slide that needs splitting.

**6. Never dim a block with inline `opacity`.** Two failures at once:
inline styles outrank the `[data-step].on` rule, so the element is stuck
semi-transparent and the stepped reveal silently breaks; and a 0.5-opacity
block on the light background lands under 2:1 contrast. To show a "before" /
weakened state, keep the text at full color and tint the container instead:

```html
<!-- wrong -->
<div class="card" style="opacity:.5;" data-step="1">…</div>
<!-- right -->
<div class="card" style="background:var(--border-light);border-color:var(--border);" data-step="1">…</div>
```

---

# v2.2 CSS block — paste into `<style>` when the template lacks it

Requires the standard token block (`--brand-rgb`, `--purple-rgb`, `--green-rgb`,
`--amber-rgb`, `--red-rgb` included) and `--font-body` / `--font-mono`.

```css
/* typography atoms */
.big-statement { font-family: var(--font-display); font-size: clamp(2.4rem, 5.4vw, 4.4rem); font-weight: 800; letter-spacing: -0.038em; line-height: 1.16; }
.grad-text { background: linear-gradient(135deg, var(--brand), var(--purple)); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; }
.hairline { width: 64px; height: 2px; background: linear-gradient(90deg, var(--brand), var(--purple)); border-radius: 2px; margin: 0 0 1.75rem; }
.mono { font-family: var(--font-mono); }
.muted { color: var(--text-muted); }
.gloss { font-size: 0.78rem; color: var(--text-secondary); font-weight: 400; }

/* labels */
.label { display: inline-block; font-size: 0.72rem; font-weight: 650; text-transform: uppercase; letter-spacing: 0.1em; padding: 5px 12px; border-radius: 100px; }
.label-blue { background: var(--brand-light); color: var(--brand); }
.label-purple { background: var(--purple-light); color: var(--purple); }
.label-green { background: var(--green-light); color: var(--green); }
.label-amber { background: var(--amber-light); color: var(--amber); }
.label-red { background: var(--red-light); color: var(--red); }
.label-gray { background: var(--border-light); color: var(--text-muted); }
.label.cn { text-transform: none; letter-spacing: 0.02em; font-size: 0.76rem; }

/* cards & grids */
.card.tight { padding: 1.15rem 1.3rem; }
.card.lift { transition: transform .22s cubic-bezier(0.23,1,0.32,1), box-shadow .22s; }
.card.lift:hover { transform: translateY(-3px); box-shadow: var(--shadow-md); }
.card .ghost-num { position: absolute; top: 10px; right: 14px; font-size: 2.1rem; font-weight: 800; color: var(--border-light); line-height: 1; }
.grid-5 { display: grid; grid-template-columns: repeat(auto-fit, minmax(190px, 1fr)); gap: 0.85rem; }
.grid-auto { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.1rem; }

/* stats */
.stat { text-align: center; }
.stat .num { font-family: var(--font-mono); font-size: clamp(2rem, 3.6vw, 3rem); font-weight: 800; line-height: 1; background: linear-gradient(135deg, var(--brand), var(--purple)); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; }
.stat .cap { font-size: 0.78rem; color: var(--text-muted); margin-top: 0.45rem; letter-spacing: .02em; }
.stat-row { display: flex; gap: 2.5rem; flex-wrap: wrap; }

/* spills */
.spill { display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.6rem 1.2rem; border-radius: 100px;
         background: rgba(var(--brand-rgb),0.07); border: 1px solid rgba(var(--brand-rgb),0.16);
         font-size: 0.82rem; font-weight: 550; color: var(--brand); }
.spill .dot { width: 7px; height: 7px; border-radius: 50%; background: currentColor; flex-shrink: 0; }
.spill.live .dot { animation: pulseDot 1.6s ease-in-out infinite; }
.spill.purple { background: rgba(var(--purple-rgb),0.07); border-color: rgba(var(--purple-rgb),0.16); color: var(--purple); }
.spill.green  { background: rgba(var(--green-rgb),0.08);  border-color: rgba(var(--green-rgb),0.18);  color: var(--green); }
.spill.amber  { background: rgba(var(--amber-rgb),0.08);  border-color: rgba(var(--amber-rgb),0.18);  color: var(--amber); }
.spill.red    { background: rgba(var(--red-rgb),0.07);    border-color: rgba(var(--red-rgb),0.16);    color: var(--red); }
@keyframes pulseDot { 0%,100%{ opacity:1; transform:scale(1); } 50%{ opacity:.45; transform:scale(1.35); } }

/* chips */
.chip { display: inline-flex; align-items: center; gap: 6px; padding: 0.32rem 0.62rem; border-radius: 8px;
        font-size: 0.72rem; color: var(--text-secondary); background: rgba(var(--brand-rgb),0.05);
        border: 1px solid rgba(var(--brand-rgb),0.16); white-space: nowrap; }
.chip.purple { background: rgba(var(--purple-rgb),0.05); border-color: rgba(var(--purple-rgb),0.16); }
.chip.green  { background: rgba(var(--green-rgb),0.06);  border-color: rgba(var(--green-rgb),0.18); }
.chip.amber  { background: rgba(var(--amber-rgb),0.06);  border-color: rgba(var(--amber-rgb),0.18); }
.chip.red    { background: rgba(var(--red-rgb),0.05);    border-color: rgba(var(--red-rgb),0.16); }
.chip.gray   { background: var(--border-light); border-color: var(--border); color: var(--text-muted); }
.chip.dashed { border-style: dashed; }
.chip svg { width: 13px; height: 13px; flex-shrink: 0; }

/* comparison — headers are body font, NOT uppercase (Chinese) */
.comparison { width: 100%; border-collapse: collapse; font-size: 0.95rem; }
.comparison th { text-align: left; padding: 0.85rem 1rem; font-weight: 650; border-bottom: 2px solid var(--border);
                 font-size: 0.8rem; letter-spacing: 0.02em; color: var(--text-secondary); font-family: var(--font-body); }
.comparison td { padding: 0.85rem 1rem; border-bottom: 1px solid var(--border-light); vertical-align: top; color: var(--text-secondary); }
.comparison tr:last-child td { border-bottom: none; }
.comparison .from-cell { color: var(--text-muted); font-style: italic; }
.comparison .to-cell { color: var(--text); font-weight: 600; }
.comparison td strong { color: var(--text); }

/* schedule */
.schedule { width: 100%; border-collapse: separate; border-spacing: 0; font-size: 0.88rem; }
.schedule th { padding: 0.65rem 0.9rem; text-align: left; font-weight: 700; font-size: 0.8rem;
               letter-spacing: 0.02em; background: var(--bg-alt); border-bottom: 2px solid var(--border); color: var(--text-secondary); font-family: var(--font-body); }
.schedule th:first-child { border-radius: var(--radius-sm) 0 0 0; }
.schedule th:last-child { border-radius: 0 var(--radius-sm) 0 0; }
.schedule td { padding: 0.6rem 0.9rem; border-bottom: 1px solid var(--border-light); vertical-align: middle; color: var(--text-secondary); }
.schedule tr:last-child td { border-bottom: none; }
.time-tag { font-family: var(--font-mono); font-size: 0.72rem; font-weight: 600; color: var(--brand);
            background: var(--brand-light); padding: 2px 8px; border-radius: 4px; white-space: nowrap; }
.time-tag.purple { color: var(--purple); background: var(--purple-light); }
.time-tag.green  { color: var(--green);  background: var(--green-light); }
.time-tag.amber  { color: var(--amber);  background: var(--amber-light); }

/* horizontal flow — arrows are automatic */
.hflow { display: flex; align-items: stretch; gap: 0; }
.hstep { flex: 1; background: var(--surface); border: 1px solid var(--border); border-radius: 13px; padding: 1rem 1.1rem; position: relative; }
.hstep + .hstep { margin-left: 32px; }
.hstep + .hstep::before { content: "→"; position: absolute; left: -25px; top: 50%; transform: translateY(-50%);
                          color: var(--text-muted); font-size: 1.05rem; line-height: 1; }
.hstep .fn { font-family: var(--font-mono); font-size: 0.62rem; font-weight: 800; color: var(--brand); margin-bottom: 5px; letter-spacing: .08em; text-transform: uppercase; }
.hstep b { font-size: 0.92rem; display: block; margin-bottom: 4px; color: var(--text); }
.hstep p { margin: 0; font-size: 0.78rem; line-height: 1.55; }

/* phases */
.phase-block { border-radius: var(--radius); padding: 1.4rem 1.6rem; border: 1px solid var(--border); }
.phase-block.p1 { background: linear-gradient(135deg,#EFF6FF,#F8FAFC); border-left: 4px solid var(--brand); }
.phase-block.p2 { background: linear-gradient(135deg,#F5F3FF,#F8FAFC); border-left: 4px solid var(--purple); }
.phase-block.p3 { background: linear-gradient(135deg,#FFFBEB,#F8FAFC); border-left: 4px solid var(--amber); }
.phase-block.p4 { background: linear-gradient(135deg,#ECFDF5,#F8FAFC); border-left: 4px solid var(--green); }

/* terminal */
.term { background: #0B1120; border-radius: var(--radius); overflow: hidden; box-shadow: var(--shadow-lg); border: 1px solid #1E293B; }
.term-bar { height: 34px; display: flex; align-items: center; gap: 7px; padding: 0 13px; background: #131C2E; border-bottom: 1px solid #1E293B; }
.term-bar .dot { width: 9px; height: 9px; border-radius: 50%; }
.term-bar .ttl { flex: 1; text-align: center; font-family: var(--font-mono); font-size: 0.66rem; color: #64748B; }
.term-body { padding: 1.1rem 1.3rem; font-family: var(--font-mono); font-size: 0.8rem; line-height: 1.85; color: #CBD5E1; overflow-x: auto; white-space: pre-wrap; }
.term-body .pr { color: #34D399; } .term-body .cm { color: #64748B; } .term-body .hl { color: #7FB6FF; }
.term-body .ok { color: #34D399; } .term-body .wr { color: #FBBF24; } .term-body .em { color: #fff; font-weight: 600; }

/* prompt block */
.prompt { background: var(--surface); border: 1px solid var(--border); border-left: 3px solid var(--brand);
          border-radius: var(--radius-sm); padding: 1rem 1.2rem; position: relative; }
.prompt .p-head { display: flex; align-items: center; gap: .6rem; margin-bottom: .55rem; }
.prompt .p-tag { font-family: var(--font-mono); font-size: 0.62rem; font-weight: 800; letter-spacing: .1em;
                 color: var(--brand); text-transform: uppercase; }
.prompt .p-body { font-size: 0.85rem; line-height: 1.75; color: var(--text-secondary); }
.prompt .p-body em { color: var(--brand); font-style: normal; font-weight: 600; background: var(--brand-light); padding: 1px 5px; border-radius: 4px; }
.copy-btn { margin-left: auto; font-family: var(--font-mono); font-size: 0.62rem; letter-spacing: .06em; color: var(--text-muted);
            background: none; border: 1px solid var(--border); border-radius: 100px; padding: .2rem .6rem; cursor: pointer; transition: color .2s, border-color .2s; }
.copy-btn:hover { color: var(--brand); border-color: var(--brand); }
.copy-btn.done { color: var(--green); border-color: var(--green); }

/* narrow screens */
@media (max-width: 900px) {
    .hflow { flex-direction: column; gap: .8rem; }
    .hstep + .hstep { margin-left: 0; margin-top: 20px; }
    .hstep + .hstep::before { content: "↓"; left: 50%; top: -22px; transform: translateX(-50%); }
    .stat-row { gap: 1.4rem; }
    .comparison, .schedule { font-size: .8rem; }
    .comparison th, .comparison td, .schedule th, .schedule td { padding: .55rem .5rem; }
}
```

`.prompt` also needs its delegated copy handler (one listener for the whole
deck, capture phase so deck paging never eats the click):

```js
document.addEventListener('click', (e) => {
    const b = e.target.closest('.copy-btn'); if (!b) return;
    e.stopPropagation();
    const box = b.closest('.prompt');
    const txt = box ? (box.querySelector('.p-body')?.innerText || '') : '';
    const done = () => { const o = b.textContent; b.textContent = '已复制 ✓'; b.classList.add('done');
                         setTimeout(() => { b.textContent = o; b.classList.remove('done'); }, 1600); };
    const legacy = () => { const ta = document.createElement('textarea'); ta.value = txt;
                           ta.style.cssText = 'position:fixed;opacity:0;'; document.body.appendChild(ta); ta.select();
                           try { document.execCommand('copy'); done(); } catch (_) {} ta.remove(); };
    if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(txt).then(done).catch(legacy);
    else legacy();
}, true);
```

`file://` decks are not a secure context, so the `execCommand` fallback is not
optional — it's the path that actually runs when Wilson opens the deck locally.
Also add `.copy-btn` to the deck's `INTERACTIVE_SEL` list so the click doesn't
page the deck.
