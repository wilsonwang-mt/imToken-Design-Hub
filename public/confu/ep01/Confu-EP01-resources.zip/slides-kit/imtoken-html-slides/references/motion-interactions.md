# Motion & interaction quality standard (from the Sigil deck sub-diagrams)

The three Sigil animated diagrams (`sigil-system-map.html`,
`sigil-approval-loop.html`, `sigil-how-it-works.html`) define the default
animation/interaction quality bar for slide mode. This file documents that
machinery. Since v2.2 the paged templates ship it built in — the sections below
describe what is already running, and give the code for the cases (scroll
template, standalone diagram files) that still need their own copy. Timings
here are the implemented values; if a template disagrees, the template wins and
this file should be corrected.

## 1. Stepped reveal — the core pattern

Diagram/flow slides never appear all at once. Elements carry `data-step="N"`
and fade+rise in sequence, so the presenter's narrative and the visual build
stay in sync.

**As of v2.2 this is built into the paged templates** — `playSteps()`, the CSS,
the `.replay` button and the `R` key are already there. Authoring a stepped
slide means adding `data-step="N"` attributes and one `<button class="replay">↻
replay</button>`; do not re-implement the machinery. The code below is the
reference implementation, for the scroll template and for standalone diagram
files that need their own copy.

```css
[data-step] { opacity: 0; transform: translateY(16px);
              transition: opacity .55s ease, transform .55s ease; }
[data-step].on { opacity: 1; transform: none; }
[data-step].scale-in { transform: scale(.88); }      /* hero objects scale in */
[data-step].scale-in.on { transform: scale(1); }
@media (prefers-reduced-motion: reduce) { * { transition-duration: .001ms !important; } }
```

```js
const REDUCE = matchMedia('(prefers-reduced-motion:reduce)').matches;
const stepTimers = [];
function clearStepTimers(){ while (stepTimers.length) clearTimeout(stepTimers.pop()); }

function playSteps(slide) {
    if (!slide) return;
    const steps  = [...slide.querySelectorAll('[data-step]')];
    const replay = slide.querySelector('.replay');
    if (!steps.length) { if (replay) replay.classList.remove('show'); return; }
    const MAX = steps.reduce((m, e) => Math.max(m, +e.dataset.step || 0), 0);
    let curStep = 0;
    const render = () => {
        steps.forEach(e => e.classList.toggle('on', (+e.dataset.step || 0) <= curStep));
        if (replay) replay.classList.toggle('show', curStep >= MAX);
    };
    clearStepTimers(); curStep = 0; render();
    const start = REDUCE ? 0 : 420, gap = REDUCE ? 0 : 950;
    for (let s = 1; s <= MAX; s++) {
        stepTimers.push(setTimeout(() => { curStep = s; render(); }, start + (s - 1) * gap));
    }
}

/* replay button — capture phase, so deck paging never eats the click */
document.addEventListener('click', (e) => {
    const r = e.target.closest('.replay');
    if (r) { e.stopPropagation(); playSteps(r.closest('.slide')); }
}, true);
```

Rules:

- 3–5 steps per diagram. Group related elements under the same step number.
- **Timing is 420ms to the first beat, 950ms between beats.** These are the
  implemented values; match them if you write your own sequencer.
- **Trigger**: `go(n)` calls `playSteps(slides[cur])` on every entry, so the
  build replays each time the presenter returns to the slide. `R` replays by
  hand (`e.key === 'r' || e.key === 'R'`).
- **Replay affordance**: a quiet mono `↻ replay` top-right; it only gets
  `.show` after the final beat lands (`curStep >= MAX`), so it never hints at a
  replay for a sequence still running.
- **Reduced motion**: `start` and `gap` both collapse to `0` — all steps turn
  on at once, immediately. Verified 4/4 steps visible on first paint. Reduced
  motion must mean *instant*, never *absent*; a `prefers-reduced-motion` guard
  that hides content is a bug.
- **`data-step` must not sit on a direct child of `.stage`.** Those children
  already run the entrance stagger (`.slide.active .stage > *`), and the two
  animations fight — the element flickers or lands in the wrong state. Put a
  plain wrapper `<div>` under `.stage` and hang `data-step` on elements inside
  it.
- The end state must be the complete diagram — printing / screenshotting a
  finished slide must show everything.

### Debugging "the element is missing"

When a screenshot or automated check reports missing elements on an animated
slide, **suspect the clock before the markup**. Two sequences run on slide
entry:

- entrance stagger: up to 0.45s delay + 0.55s duration → settled by ~1.0s
- stepped reveal: last beat at `420 + (N-1) × 950` ms, plus 550ms to finish
  fading — a 4-step slide is not complete until ~3.8s

Screenshot after both have finished, or the capture is simply early. And do not
"fix" it by force-adding `.on` — `playSteps()` owns those classes and its
pending timers will overwrite whatever you set on the next beat. Wait the
sequence out, or call `playSteps()` with reduced motion on.

## 2. Embedding animated diagrams in a deck

When the diagram IS the slide, author it as its own self-contained HTML next
to the deck and embed full-bleed:

```html
<section data-label="How it works">
  <iframe src="assets/how-it-works.html" data-autoplay
          style="width:100%; height:100%; border:0; display:block;"></iframe>
</section>
```

Replay on every slide entry — **already wired in v2.2**: `go(n)` posts
`deck-play` into any `data-autoplay` iframe on the slide that just became
active. The `data-autoplay` attribute is all the slide author adds.

```js
slides[cur].querySelectorAll('iframe[data-autoplay]').forEach(f => {
    if (f.contentWindow) { try { f.contentWindow.postMessage({ type: 'deck-play' }, '*'); } catch(_){} }
});
```

The diagram file listens for it and re-runs its own `play()`:

```js
window.addEventListener('message', function(e){
  if (e.data && e.data.type === 'deck-play') play();
});
```

An oversized diagram authored at 1920×1080 can be embedded scaled:
`style="width:1920px; height:1080px; transform:scale(0.66);
transform-origin:top left;"`.

Alternative for simpler cases: inline the diagram SVG directly in the slide
and run the same `[data-step]` script scoped to that slide (trigger `play()`
when the slide becomes active). Prefer inline when the diagram has no heavy
internal script — fewer files, still self-contained.

## 3. Connector & flow animation vocabulary

- **Arrow lines**: 2px gradient line `linear-gradient(90deg,
  rgba(90,166,255,.15), #5aa6ff)` with a CSS-triangle arrowhead — reads as
  directional even before animating.
- **Flow dashes** (data moving along a path):
  `stroke-dasharray` + `@keyframes flow { to { stroke-dashoffset:-28; } }`
  on an SVG path, 1–2s linear infinite. Only while its step is active.
- **Numbered badges** on connectors: 17px-radius circle, `--panel-2` fill,
  accent stroke, mono number. The legend repeats the numbers in prose.
- **Line semantics** (keep consistent across a deck): solid accent =
  active/trusted path; dashed gray = passive notification; dashed light-blue
  = read-only status; green = allow; red = block.

## 4. Ambient/decorative motion (use sparingly)

Named keyframes from the house style — at most one or two per slide,
decoration layer only (orbs, background glows), never on text content:

```css
@keyframes float  { 0%,100%{transform:translateY(0) rotate(-2deg);} 50%{transform:translateY(-14px) rotate(1deg);} }
@keyframes orb    { 0%,100%{opacity:.45; transform:scale(1);} 50%{opacity:.8; transform:scale(1.14);} }
@keyframes drift  { 0%,100%{transform:translate(0,0);} 50%{transform:translate(46px,-34px);} }
@keyframes rise   { from{opacity:0; transform:translateY(26px);} to{opacity:1; transform:none;} }
```

Shimmer headlines: see `dark-mode.md`. Infinite loops are allowed ONLY on
decoration (orbs, shimmer) — never on informational content.

## 5. Interaction checklist for any animated slide

- [ ] Steps reveal in narrative order; nothing important appears at step 0
      except the frame/title.
- [ ] No `data-step` on a direct child of `.stage` (entrance stagger conflict).
- [ ] No inline `opacity` on a `[data-step]` element — it outranks `.on` and
      freezes the element mid-reveal (see `components.md`, red line #6).
- [ ] Replay button appears only after the last step, and works.
- [ ] Re-entering the slide replays the sequence (`go(n)` → `playSteps`, or
      postMessage into a `data-autoplay` iframe).
- [ ] `prefers-reduced-motion` collapses everything to instant-on — all steps
      visible, none missing.
- [ ] Click targets inside slides (links, replay, copy) stop propagation so they
      don't trigger deck paging.
- [ ] **Selecting text with the mouse does not turn the page.** Drag across a
      paragraph and double-click a word — in both cases the text must end up
      selected and the slide index must not change. See `SKILL.md` §8 for the
      three guards (drag tolerance, existing-selection check, double-click
      grace period); test with a real pointer, since a synthetic `click()`
      bypasses `pointerdown` and will pass even on a broken build.
- [ ] End state is complete and print-safe.
- [ ] Screenshots taken after ~1.0s entrance + `420 + (N-1)×950 + 550` ms of
      step sequence.
