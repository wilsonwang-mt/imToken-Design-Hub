# Slides Kit — 会前十分钟，用 Skill 准备一次亮眼的演讲

> Confu · 设计师 AI 工具箱 EP01 · 现场资源包
> 目标：**十分钟内**，让你手上的项目资料变成一份可以直接投屏的 HTML slides。

---

## 先看这一段（30 秒）

Skill 没有技术门槛。**它就是一个文件夹**：一份 Markdown 说明书 + 几个 HTML 模板。
任何能读文件的 AI 都能用它 —— 差别只在于是「自动触发」还是「手动指路」。

所以下面五条路，用的是同一份说明书，只是投递方式不同。**找到你自己那一条就行。**

---

## 找到你的那条路

### ① ChatGPT（大多数人走这条）

**最快：用共享的 GPT，零安装**
点 Wilson 发的「imToken Slides Maker」链接 → 直接开聊 → 粘贴或上传你的素材 → 它会先问你三四个问题 → 回答完就会输出 HTML。

**或者：自己开一个新对话**
1. 打开 `PROMPT-PACK.md`，把里面那一整段 prompt 复制粘贴进新对话
2. 把 `assets/template-paged-lite.html` 上传给它（可选，但强烈建议 —— 有模板出来的东西好看很多）
3. 贴上你的素材，回答它的问题
4. 把它输出的代码块另存为 `你的名字-slides.html`，双击打开

> 想自己也建一个共享 GPT？看 `CUSTOM-GPT-INSTRUCTIONS.md`，照着填即可。

### ② Claude 桌面版 / 网页版（Cowork）

**Customize → Skills → 「+」→ Create skill → Upload a skill**，上传 `imtoken-html-slides.zip`。
之后只要说一句「帮我做份 slides」，它会自己去读说明书。

> 已经装过旧版？Claude 目前没有「就地更新」，需要先把旧的删掉（关掉开关 → `...` → Delete），再传新的。

### ③ Claude Code（终端）

```bash
# 个人级：所有项目都能用
cp -r imtoken-html-slides ~/.claude/skills/

# 项目级：放进仓库，团队 clone 下来就有（推荐）
mkdir -p .claude/skills && cp -r imtoken-html-slides .claude/skills/
```

### ④ Gemini / Kimi (K3) 网页版

同 ChatGPT 的第二条路：粘贴 `PROMPT-PACK.md` 里的 prompt。
Gemini 可以把它存成一个 **Gem**，Kimi 存成**自定义指令**，之后就不必每次重新粘贴。

### ⑤ Cursor / Codex / Gemini CLI / Kimi CLI

把 `imtoken-html-slides/` 拖进你的项目，然后在规则文件里加一行：

```
当被要求制作 slides / 演示文稿 / 汇报材料时，先完整阅读
`imtoken-html-slides/SKILL.md` 并严格遵循，模板在 `imtoken-html-slides/assets/`。
```

放哪个文件：Cursor → `AGENTS.md` 或 `.cursor/rules/`｜Codex → `AGENTS.md`｜Gemini CLI → `GEMINI.md`｜Kimi CLI → 项目根的指令文件。

---

## 装好了，第一句说什么

**起步 Prompt（做一份汇报）**

```
我要为 [项目名] 做一份 [N] 页的进展汇报 slides，听众是 [谁]，时长 [X] 分钟。
素材在 [附件 / 文件夹 / 粘贴如下]。
请先告诉我你缺哪些信息、再开始制作；没有的内容不要编造，用占位符标注。
```

最后那句「**先问再做、不要编造**」是整段里最值钱的部分 —— 它能挡掉绝大部分编造。

**没有素材？** 用 `sample-project/` —— 一个完全虚构的项目（Northwind 的协同批注功能），
资料齐全、前后一致，用它练手一定跑得通。三个练习题目写在 `sample-project/README.md` 里。

---

## 回去之后，真正让它变强的那一步

今天的 Skill 只解决「长得好不好看」。真正让最后十分钟变轻松的，是**从项目第一天就开始攒上下文**。

回工位第一件事：给你手上的项目建一个 `CLAUDE.md`（叫 `AGENTS.md`、`README-for-AI.md` 都行，
换个名字而已）。写 30 行也够。用这段 prompt 让 AI 帮你起草：

```
这是一个新项目：[一句话描述]。请为它创建一份 CLAUDE.md，包含：
项目背景与目标、我的角色、目录结构约定、关键决策记录（先留空表）、
团队成员表、术语表（先留空表）、时间线。
以后每次我们的对话产生新的决策、新人名、新术语，都主动提醒我更新这份文件。
```

然后每个节点（开完会、评完审、跑完一个 sprint）让它写一次纪要 + 决策记录，存进项目文件夹。

> 术语表那一栏不要空着 —— 把语音转写老听错的词写进去（比如会议转写把 VETA 听成 Better）。
> 写一次，往后每一份纪要都少犯一次同样的错。

---

## 包里都有什么

| 文件 | 给谁 |
|---|---|
| `README.md` | 你正在看的这份，先读它 |
| `两条真实的-Prompt.md` | 今天这套 slides 的全部指令原文 + 逐段拆解，可抄走 |
| `PROMPT-PACK.md` | 网页版 AI（ChatGPT / Gemini / Kimi）直接粘贴 |
| `CUSTOM-GPT-INSTRUCTIONS.md` | 想自己建共享 GPT 的人 |
| `assets/template-paged-lite.html` | 精简模板，上传给网页版 AI 当骨架 |
| `imtoken-html-slides/` | 完整 Skill（SKILL.md + 3 个模板 + 4 份 references） |
| `sample-project/` | 虚构的练手素材，手边没有资料时用它 |
| `jobs-six-moves-cheatsheet.html` | 《乔布斯的魔力演讲》六招速查卡，可打印 A4 |

---

## 卡住了？

**AI 说输出太长 / 中途断了** → 让它「接着上面继续输出，不要重复已经给过的部分」；
或者让它分两次给（先 CSS 骨架，再 slides）。也可以删掉 lite 模板里那段 logo SVG（约 9 KB），页脚改用文字 wordmark。

**生成的内容是编造的** → 你的 prompt 里少了「不要编造，用占位符标注」这句。加上，重来一次。

**它一上来就直接开做，没问我问题** → 说一句「先按你的 Step 0 协议问我问题，不要直接做」。

**中文字重不对 / 排版异常** → 确认它保留了 `'Inter','Noto Sans SC',…,'PingFang SC'` 这一整串字体栈。
Inter 没有中文字形，中文本来就是由后面的 CJK 字体渲染的 —— 这个搭配是故意的。

**想要暗色主题** → 直接说「改成暗色主题」。完整 Skill 里有 `references/dark-mode.md`，
网页版 AI 则会自己换算 —— 记得让它把品牌蓝从 `#007FFF` 换成 `#5aa6ff` —— 深色背景上原来的蓝色太暗。

---

## 最后一句

AI 拉平了「制作」，所以「表达」比以往任何时候都值钱。
把省下来的时间，还给排练。
